# SwipeDeleteItemRecyclerVieew
Swipe item delete recyclerview
