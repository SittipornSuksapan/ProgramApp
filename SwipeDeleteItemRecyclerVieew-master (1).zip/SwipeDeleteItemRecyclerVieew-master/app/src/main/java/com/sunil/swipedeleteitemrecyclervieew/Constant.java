package com.sunil.swipedeleteitemrecyclervieew;

/**
 * Created by kuliza-195 on 11/29/16.
 */

public class Constant {

    public static String [] name = {"Bangalore", "Chennai", "Kolkata", "Delhi", "Mumbai", "Pune"};
    public static String [] image = {"http://farm8.staticflickr.com/7452/27782542462_12e206359b_m.jpg",
            "http://farm8.staticflickr.com/7311/27782539412_1e1cece561_m.jpg",
            "http://farm8.staticflickr.com/7452/27782542462_12e206359b_m.jpg",
            "http://farm8.staticflickr.com/7326/27605634010_917553d601_m.jpg",
            "http://farm8.staticflickr.com/7452/27782542462_12e206359b_m.jpg",
            "http://farm8.staticflickr.com/7311/27782539412_1e1cece561_m.jpg"};

}

