package com.sunil.swipedeleteitemrecyclervieew;

/**
 * Created by kuliza-195 on 11/30/16.
 */

public interface Extension {

    float getActionWidth();
}