# swipelistview

Slide-Out Menu iOS Readme

Since I noticed the swipeable listview in Gmail mobile app, I couldn’t help myself but learn how to implement the same feature in our client’s app. It also become very popular in short period and it turned out to be very useful in mobile apps as well.

Thus, I finally decided to create a demo on it and written a tutorial on [How to Improve App UI With Swipe to Delete Listview Android Example](
https://www.spaceotechnologies.com/swipe-delete-listview-android-example/)

If you face any issue implementing it, you can contact me for help. Also, if you want to implement this feature in your Android app and looking to [hire Android app developer](http://www.spaceotechnologies.com/hire-android-developer/ 
) to help you, then you can contact Space-O Technologies for the same.

